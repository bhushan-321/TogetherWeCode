package com.electronicBE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElectronicStoreBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
